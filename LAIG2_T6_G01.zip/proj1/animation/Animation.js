class Animation {
    update(){
        throw new Error('Method not implemented');
    }

    apply(){
        throw new Error('Method not implemented');
    }
}